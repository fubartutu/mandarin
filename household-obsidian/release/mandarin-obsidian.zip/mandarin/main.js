"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => MandarinPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");

// src/api.ts
var DEFAULT_SETTINGS = {
  url: "",
  token: "",
  cfClientId: "",
  cfClientSecret: "",
  recipeFolder: "Recipes",
  defaultProjectId: 0,
  defaultDueTime: "17:00",
  finishedProjectIds: [],
  finishedHeading: "## \u2705 Done in Mandarin",
  finishedAuto: false
};
var ApiError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
  status;
};
function hasDate(iso) {
  return Boolean(iso) && !iso.startsWith("0001-");
}
var MandarinApi = class {
  constructor(settings, transport2) {
    this.settings = settings;
    this.transport = transport2;
  }
  settings;
  transport;
  /** The web address of a page in Mandarin, e.g. a task. */
  pageUrl(path) {
    return this.settings().url.replace(/\/+$/, "") + path;
  }
  async request(method, path, body, contentType = "application/json") {
    const s = this.settings();
    if (!s.url || !s.token) throw new ApiError(0, "Set the Mandarin address and API token in the plugin settings.");
    const headers = {
      "Authorization": `Bearer ${s.token}`,
      "Accept": "application/json"
    };
    if (s.cfClientId && s.cfClientSecret) {
      headers["CF-Access-Client-Id"] = s.cfClientId;
      headers["CF-Access-Client-Secret"] = s.cfClientSecret;
    }
    if (body !== void 0) headers["Content-Type"] = contentType;
    const response = await this.transport({
      url: this.pageUrl("/api/v2" + path),
      method,
      headers,
      body: body === void 0 ? void 0 : JSON.stringify(body)
    });
    if (response.status >= 400) throw new ApiError(response.status, describe(response));
    if (response.text.trimStart().startsWith("<")) {
      throw new ApiError(response.status, "Got a web page instead of Mandarin: check the Cloudflare service token.");
    }
    return response;
  }
  async json(method, path, body, contentType) {
    const response = await this.request(method, path, body, contentType);
    return response.text ? JSON.parse(response.text) : void 0;
  }
  /** Every page of a list endpoint. */
  async all(path) {
    const out = [];
    const join = path.includes("?") ? "&" : "?";
    for (let page = 1; ; page++) {
      const data = await this.json("GET", `${path}${join}page=${page}&per_page=100`);
      out.push(...data.items ?? []);
      if (page >= (data.total_pages ?? 1)) return out;
    }
  }
  projects() {
    return this.all("/projects");
  }
  /** Tasks matching a Vikunja filter (https://vikunja.io/docs/filters), by due date. */
  tasks(filter, sortBy = "due_date", timezone = Intl.DateTimeFormat().resolvedOptions().timeZone) {
    const query = new URLSearchParams({ filter_timezone: timezone });
    if (filter) query.set("filter", filter);
    query.append("sort_by", sortBy);
    query.append("order_by", "asc");
    return this.all(`/tasks?${query}`);
  }
  setDone(taskId, done) {
    return this.json("PATCH", `/tasks/${taskId}`, { done }, "application/merge-patch+json");
  }
  createTask(projectId, task) {
    return this.json("POST", `/projects/${projectId}/tasks`, task);
  }
  recipes() {
    return this.all("/recipes");
  }
  async recipeImage(recipeId, imageId) {
    const response = await this.request("GET", `/recipes/${recipeId}/images/${imageId}`);
    return response.arrayBuffer;
  }
};
function describe(response) {
  try {
    const problem = JSON.parse(response.text);
    const reason = problem.detail || problem.message || problem.title;
    if (reason) return `Mandarin answered ${response.status}: ${reason}`;
  } catch {
  }
  if (response.status === 401) return "Mandarin refused the API token.";
  if (response.status === 403) return "Not allowed: check the API token's permissions (or the Cloudflare service token).";
  return `Mandarin answered ${response.status}.`;
}

// src/markdown.ts
var LIST_MARKER = /^(\s*)([-*+]|\d+[.)])\s+(\[[ xX]\]\s+)?/;
var DUE = /\s*(?:📅\s*|\bdue::?\s*)(\d{4}-\d{2}-\d{2})\b/u;
var MANDARIN_LINK = /\[[^\]]*\]\((https?:\/\/[^)\s]+\/tasks\/\d+)\)/;
function lineToTask(line) {
  let text = line.replace(LIST_MARKER, "");
  let due = null;
  const m = DUE.exec(text);
  if (m) {
    due = m[1];
    text = text.replace(m[0], " ");
  }
  const title = text.replace(/\s+/g, " ").trim();
  return title ? { title, due } : null;
}
function linkedTask(line) {
  return MANDARIN_LINK.exec(line)?.[1] ?? null;
}
function withTaskLink(line, taskUrl) {
  return `${line.replace(/\s+$/, "")} [\u2197 Mandarin](${taskUrl})`;
}
function dueTimestamp(date, time) {
  const [h, m] = (time.match(/^\d{1,2}:\d{2}$/) ? time : "17:00").split(":").map(Number);
  const [y, mo, d] = date.split("-").map(Number);
  return new Date(y, mo - 1, d, h, m).toISOString();
}
function noteLink(vault, path) {
  return `obsidian://open?vault=${encodeURIComponent(vault)}&file=${encodeURIComponent(path)}`;
}
function parseBlock(source) {
  const options = { limit: 50, showDone: false };
  for (const raw of source.split("\n")) {
    const line = raw.replace(/#.*$/, "").trim();
    const i = line.indexOf(":");
    if (i < 0) continue;
    const key = line.slice(0, i).trim().toLowerCase();
    const value = line.slice(i + 1).trim();
    if (key === "project") options.project = value;
    else if (key === "filter") options.filter = value;
    else if (key === "title") options.title = value;
    else if (key === "limit") options.limit = Math.max(1, Number(value) || 50);
    else if (key === "show-done" || key === "done") options.showDone = /^(true|yes|1)$/i.test(value);
  }
  return options;
}
function blockFilter(options, projectId) {
  const parts = [];
  if (!options.showDone) parts.push("done = false");
  if (projectId) parts.push(`project = ${projectId}`);
  if (options.filter) parts.push(`(${options.filter})`);
  return parts.join(" && ");
}
function safeFileName(title) {
  return title.replace(/[\\/:*?"<>|#^[\]]/g, " ").replace(/\s+/g, " ").trim().slice(0, 120) || "Recipe";
}
function minutes(m) {
  if (!m) return null;
  const h = Math.floor(m / 60);
  return [h ? `${h} h` : "", m % 60 ? `${m % 60} min` : ""].filter(Boolean).join(" ");
}
function tag(text) {
  return text.trim().toLowerCase().replace(/[^\p{L}\p{N}/_-]+/gu, "-").replace(/^-+|-+$/g, "");
}
function yamlString(value) {
  return JSON.stringify(value);
}
function recipeMarkdown(recipe, mandarinUrl, imageLink) {
  const front = ["---", `mandarin: ${yamlString(mandarinUrl)}`];
  if (recipe.source_url) front.push(`source: ${yamlString(recipe.source_url)}`);
  if (recipe.servings) front.push(`servings: ${recipe.servings}`);
  if (recipe.yields) front.push(`yields: ${yamlString(recipe.yields)}`);
  for (const [key, value] of [["prep", recipe.prep_minutes], ["cook", recipe.cook_minutes], ["total", recipe.total_minutes]]) {
    const text = minutes(value);
    if (text) front.push(`${key}: ${yamlString(text)}`);
  }
  const tags = ["recipe", ...recipe.tags.map(tag).filter(Boolean)];
  front.push(`tags: [${[...new Set(tags)].join(", ")}]`, "---", "");
  const body = [`# ${recipe.title}`, ""];
  if (imageLink) body.push(imageLink, "");
  if (recipe.description) body.push(recipe.description, "");
  body.push("## Ingredients", "");
  let group = "";
  for (const ingredient of recipe.ingredients) {
    if (ingredient.group !== group) {
      group = ingredient.group;
      if (group) body.push("", `### ${group}`, "");
    }
    body.push(`- ${ingredient.text}`);
  }
  body.push("");
  if (recipe.steps.length) {
    body.push("## Method", "");
    let n = 0;
    for (const step of recipe.steps) {
      if (step.endsWith(":") && !/^\d/.test(step)) body.push("", `### ${step.slice(0, -1)}`, "");
      else body.push(`${++n}. ${step}`);
    }
    body.push("");
  }
  if (recipe.notes) body.push("## Notes", "", recipe.notes, "");
  return [...front, ...body].join("\n").replace(/\n{3,}/g, "\n\n");
}
function withSubProjects(projects, ids) {
  const out = new Set(ids);
  let grew = true;
  while (grew) {
    grew = false;
    for (const p of projects) {
      if (p.parent_project_id && out.has(p.parent_project_id) && !out.has(p.id)) {
        out.add(p.id);
        grew = true;
      }
    }
  }
  return [...out];
}
function finishedFilter(day, nextDay, projectIds) {
  return `done_at >= ${day} && done_at < ${nextDay} && project in ${projectIds.join(", ")}`;
}
var START = "%% mandarin-finished: start %%";
var END = "%% mandarin-finished: end %%";
function finishedList(groups) {
  const filled = groups.filter((g) => g.tasks.length > 0);
  if (filled.length === 0) return "- Nothing finished.";
  const lines = [];
  for (const group of filled) {
    if (filled.length > 1) {
      if (lines.length) lines.push("");
      lines.push(`### ${group.project}`);
    }
    for (const task of group.tasks) lines.push(`- [x] [${task.title.replace(/[[\]]/g, "")}](${task.url})`);
  }
  return lines.join("\n");
}
function withFinishedTasks(note, heading, list) {
  const block = `${START}
${list}
${END}`;
  const start = note.indexOf(START);
  const end = note.indexOf(END, start);
  if (start >= 0 && end >= 0) return note.slice(0, start) + block + note.slice(end + END.length);
  const lines = note.split("\n");
  const at = lines.findIndex((line) => line.trim() === heading.trim());
  if (at >= 0) {
    lines.splice(at + 1, 0, block);
    return lines.join("\n");
  }
  return `${note.replace(/\s+$/, "")}${note.trim() ? "\n\n" : ""}${heading}
${block}
`;
}
function fillTemplate(template, title, format) {
  return template.replace(/{{\s*title\s*}}/gi, title).replace(/{{\s*(date|time)\s*(?::(.*?))?\s*}}/gi, (_, kind, pattern) => format(pattern?.trim() || (kind.toLowerCase() === "date" ? "YYYY-MM-DD" : "HH:mm")));
}

// src/main.ts
var moment = import_obsidian.moment;
var VIEW_TYPE = "mandarin-tasks";
var transport = async (request) => {
  const response = await (0, import_obsidian.requestUrl)({ ...request, throw: false });
  return { status: response.status, text: response.text, arrayBuffer: response.arrayBuffer };
};
function dailyNoteOptions(app) {
  const internal = app.internalPlugins;
  const options = internal?.getPluginById?.("daily-notes")?.instance?.options ?? {};
  return { folder: options.folder ?? "", format: options.format || "YYYY-MM-DD", template: options.template ?? "" };
}
function errorText(e) {
  return e instanceof ApiError || e instanceof Error ? e.message : String(e);
}
var MandarinPlugin = class extends import_obsidian.Plugin {
  settings = { ...DEFAULT_SETTINGS };
  api = new MandarinApi(() => this.settings, transport);
  async onload() {
    this.settings = { ...DEFAULT_SETTINGS, ...await this.loadData() };
    this.addSettingTab(new MandarinSettingTab(this.app, this));
    this.registerView(VIEW_TYPE, (leaf) => new TasksView(leaf, this));
    this.addRibbonIcon("check-square", "Mandarin tasks", () => this.openTasks());
    this.addCommand({ id: "open-tasks", name: "Open tasks", callback: () => this.openTasks() });
    this.addCommand({
      id: "line-to-task",
      name: "Create task from this line",
      editorCallback: (editor, view) => this.lineToTask(editor, view)
    });
    this.registerEvent(this.app.workspace.on("editor-menu", (menu, editor, view) => {
      menu.addItem((item) => item.setTitle("Create Mandarin task").setIcon("check-square").onClick(() => this.lineToTask(editor, view)));
    }));
    this.addCommand({ id: "import-recipe", name: "Save a recipe as a note", callback: () => new RecipeModal(this).open() });
    this.registerMarkdownCodeBlockProcessor("mandarin-tasks", async (source, el) => {
      await this.renderBlock(source, el);
    });
    this.addCommand({
      id: "finished-to-daily-note",
      name: "Add finished tasks to the daily note",
      callback: () => this.finishedToDailyNote()
    });
    this.app.workspace.onLayoutReady(() => {
      void this.autoFinished(true);
      this.registerInterval(window.setInterval(() => void this.autoFinished(false), 30 * 6e4));
    });
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  async openTasks() {
    const existing = this.app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    const leaf = existing ?? this.app.workspace.getRightLeaf(false);
    if (!leaf) return;
    await leaf.setViewState({ type: VIEW_TYPE, active: true });
    this.app.workspace.revealLeaf(leaf);
  }
  // ---- Note line → task ----
  async lineToTask(editor, view) {
    const lineNo = editor.getCursor().line;
    const line = editor.getLine(lineNo);
    const existing = linkedTask(line);
    if (existing) {
      new import_obsidian.Notice("This line already has a Mandarin task.");
      return;
    }
    const parsed = lineToTask(line);
    if (!parsed) {
      new import_obsidian.Notice("Put the cursor on a line with some text.");
      return;
    }
    const projectId = this.settings.defaultProjectId;
    if (!projectId) {
      new import_obsidian.Notice("Pick a project for new tasks in the Mandarin plugin settings.");
      return;
    }
    const file = view.file;
    try {
      const task = await this.api.createTask(projectId, {
        title: parsed.title,
        description: file ? `<p>From <a href="${noteLink(this.app.vault.getName(), file.path)}">${file.basename}</a> in Obsidian.</p>` : void 0,
        due_date: parsed.due ? dueTimestamp(parsed.due, this.settings.defaultDueTime) : void 0
      });
      if (editor.getLine(lineNo) === line) {
        editor.setLine(lineNo, withTaskLink(line, this.api.pageUrl(`/tasks/${task.id}`)));
      }
      new import_obsidian.Notice(`Task created: ${task.title}`);
    } catch (e) {
      new import_obsidian.Notice(`Couldn't create the task. ${errorText(e)}`);
    }
  }
  // ---- mandarin-tasks code block ----
  async renderBlock(source, el) {
    const options = parseBlock(source);
    el.addClass("mandarin-block");
    const status = el.createDiv({ cls: "mandarin-muted", text: "Loading tasks\u2026" });
    try {
      let projectId = null;
      if (options.project) {
        const projects = await this.api.projects();
        const wanted = options.project.toLowerCase();
        const found = projects.find((p) => String(p.id) === options.project || p.title.toLowerCase() === wanted);
        if (!found) throw new Error(`No project called "${options.project}".`);
        projectId = found.id;
      }
      const tasks = (await this.api.tasks(blockFilter(options, projectId))).slice(0, options.limit);
      status.remove();
      if (options.title) el.createEl("h4", { text: options.title });
      renderTasks(el, tasks, this, () => this.renderBlockAgain(source, el));
    } catch (e) {
      status.setText(`Mandarin: ${errorText(e)}`);
    }
  }
  async renderBlockAgain(source, el) {
    el.empty();
    await this.renderBlock(source, el);
  }
  // ---- Recipe → note ----
  async saveRecipe(recipe) {
    const folder = (0, import_obsidian.normalizePath)(this.settings.recipeFolder || "Recipes");
    const path = (0, import_obsidian.normalizePath)(`${folder}/${safeFileName(recipe.title)}.md`);
    const existing = this.app.vault.getAbstractFileByPath(path);
    if (existing instanceof import_obsidian.TFile) {
      new import_obsidian.Notice("Already in your vault. Delete the note to save it again.");
      await this.app.workspace.getLeaf(false).openFile(existing);
      return;
    }
    try {
      await this.ensureFolder(folder);
      let imageLink = "";
      if (recipe.image_ids.length > 0) {
        const attachments = (0, import_obsidian.normalizePath)(`${folder}/attachments`);
        await this.ensureFolder(attachments);
        const imagePath = (0, import_obsidian.normalizePath)(`${attachments}/${safeFileName(recipe.title)}.jpg`);
        if (!this.app.vault.getAbstractFileByPath(imagePath)) {
          const data = await this.api.recipeImage(recipe.id, recipe.image_ids[0]);
          await this.app.vault.createBinary(imagePath, data);
        }
        imageLink = `![[${imagePath}]]`;
      }
      const note = await this.app.vault.create(path, recipeMarkdown(recipe, this.api.pageUrl(`/recipes/${recipe.id}`), imageLink));
      await this.app.workspace.getLeaf(false).openFile(note);
      new import_obsidian.Notice(`Saved ${recipe.title}`);
    } catch (e) {
      new import_obsidian.Notice(`Couldn't save the recipe. ${errorText(e)}`);
    }
  }
  // ---- Finished tasks → daily note ----
  /** The command: the open daily note's day, or today. Creates the note if needed and opens it. */
  async finishedToDailyNote() {
    if (this.settings.finishedProjectIds.length === 0) {
      new import_obsidian.Notice("Pick the projects for the daily note in the Mandarin plugin settings.");
      return;
    }
    const active = this.app.workspace.getActiveFile();
    const day = active && this.dailyNoteDay(active) || moment().startOf("day");
    try {
      const file = await this.writeFinished(day, true);
      if (file && file !== active) await this.app.workspace.getLeaf(false).openFile(file);
      new import_obsidian.Notice(`Finished tasks added to ${day.format("ddd D MMM")}.`);
    } catch (e) {
      new import_obsidian.Notice(`Couldn't add finished tasks. ${errorText(e)}`);
    }
  }
  /**
   * The automatic update: today's note, plus yesterday's at start-up (for tasks
   * finished late in the evening). It only creates a note when something was finished,
   * and stays quiet on errors (offline, for instance).
   */
  async autoFinished(startup) {
    if (!this.settings.finishedAuto || this.settings.finishedProjectIds.length === 0) return;
    const today = moment().startOf("day");
    const days = startup ? [today.clone().subtract(1, "day"), today] : [today];
    for (const day of days) {
      try {
        await this.writeFinished(day, false);
      } catch (e) {
        console.warn("Mandarin: couldn't update the daily note", e);
        return;
      }
    }
  }
  /** The day a note is the daily note for, if it is one. */
  dailyNoteDay(file) {
    const options = dailyNoteOptions(this.app);
    const folder = (0, import_obsidian.normalizePath)(options.folder || "/");
    const inFolder = folder === "/" ? !file.path.includes("/") : file.parent?.path === folder;
    if (!inFolder) return null;
    const day = moment(file.basename, options.format, true);
    return day.isValid() ? day.startOf("day") : null;
  }
  /**
   * Puts the day's finished tasks in its daily note. With create false, a missing note is
   * only made when there's something to put in it. Writes nothing when nothing changed
   * (LiveSync would carry every write to the other devices).
   */
  async writeFinished(day, create) {
    const projects = await this.api.projects();
    const ids = withSubProjects(projects, this.settings.finishedProjectIds);
    const filter = finishedFilter(day.format("YYYY-MM-DD"), day.clone().add(1, "day").format("YYYY-MM-DD"), ids);
    const tasks = await this.api.tasks(filter, "done_at");
    const titles = new Map(projects.map((p) => [p.id, p.title]));
    const byProject = /* @__PURE__ */ new Map();
    for (const id of ids) byProject.set(id, { project: titles.get(id) ?? `Project ${id}`, tasks: [] });
    for (const task of tasks) {
      byProject.get(task.project_id)?.tasks.push({ title: task.title, url: this.api.pageUrl(`/tasks/${task.id}`) });
    }
    const list = finishedList([...byProject.values()]);
    let file = this.dailyNoteFile(day);
    if (!file) {
      if (!create && tasks.length === 0) return null;
      file = await this.createDailyNote(day);
    }
    const heading = this.settings.finishedHeading.trim() || DEFAULT_SETTINGS.finishedHeading;
    const before = await this.app.vault.read(file);
    if (withFinishedTasks(before, heading, list) !== before) {
      await this.app.vault.process(file, (text) => withFinishedTasks(text, heading, list));
    }
    return file;
  }
  dailyNotePath(day) {
    const options = dailyNoteOptions(this.app);
    return (0, import_obsidian.normalizePath)(`${options.folder || ""}/${day.format(options.format)}.md`);
  }
  dailyNoteFile(day) {
    const file = this.app.vault.getAbstractFileByPath(this.dailyNotePath(day));
    return file instanceof import_obsidian.TFile ? file : null;
  }
  /** A new daily note from the Daily notes template, filled in like Obsidian does. */
  async createDailyNote(day) {
    const options = dailyNoteOptions(this.app);
    const path = this.dailyNotePath(day);
    let text = "";
    if (options.template) {
      const templatePath = (0, import_obsidian.normalizePath)(options.template.endsWith(".md") ? options.template : `${options.template}.md`);
      const template = this.app.vault.getAbstractFileByPath(templatePath);
      if (template instanceof import_obsidian.TFile) {
        const title = path.split("/").pop().replace(/\.md$/, "");
        text = fillTemplate(await this.app.vault.read(template), title, (pattern) => day.format(pattern));
      }
    }
    const folder = path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "";
    if (folder) await this.ensureFolder(folder);
    return this.app.vault.create(path, text);
  }
  async ensureFolder(path) {
    if (!this.app.vault.getAbstractFileByPath(path)) await this.app.vault.createFolder(path);
  }
};
function dueText(task) {
  if (!hasDate(task.due_date)) return "";
  const due = new Date(task.due_date);
  const today = /* @__PURE__ */ new Date();
  const day = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const diff = Math.round((day(due) - day(today)) / 864e5);
  const time = due.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (diff === 0) return `today ${time}`;
  if (diff === 1) return `tomorrow ${time}`;
  if (diff === -1) return "yesterday";
  if (diff < 0) return `${-diff} days ago`;
  return due.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" });
}
function renderTasks(el, tasks, plugin, refresh) {
  if (tasks.length === 0) {
    el.createDiv({ cls: "mandarin-muted", text: "Nothing here." });
    return;
  }
  const list = el.createEl("ul", { cls: "mandarin-tasks" });
  const now = Date.now();
  for (const task of tasks) {
    const li = list.createEl("li", { cls: "mandarin-task" });
    const box = li.createEl("input", { type: "checkbox" });
    box.checked = task.done;
    box.addEventListener("change", async () => {
      box.disabled = true;
      try {
        await plugin.api.setDone(task.id, box.checked);
        li.toggleClass("is-done", box.checked);
        window.setTimeout(refresh, 800);
      } catch (e) {
        box.checked = !box.checked;
        new import_obsidian.Notice(`Couldn't update the task. ${errorText(e)}`);
      } finally {
        box.disabled = false;
      }
    });
    const link = li.createEl("a", { text: task.title, href: plugin.api.pageUrl(`/tasks/${task.id}`) });
    link.addClass("mandarin-task-title");
    const due = dueText(task);
    if (due) {
      const overdue = hasDate(task.due_date) && new Date(task.due_date).getTime() < now && !task.done;
      li.createSpan({ cls: overdue ? "mandarin-due is-overdue" : "mandarin-due", text: due });
    }
  }
}
var TasksView = class extends import_obsidian.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
  }
  plugin;
  timer = 0;
  getViewType() {
    return VIEW_TYPE;
  }
  getDisplayText() {
    return "Mandarin tasks";
  }
  getIcon() {
    return "check-square";
  }
  async onOpen() {
    await this.refresh();
    this.timer = window.setInterval(() => this.refresh(), 5 * 6e4);
    this.registerInterval(this.timer);
  }
  async refresh() {
    const root = this.contentEl;
    root.empty();
    root.addClass("mandarin-view");
    const header = root.createDiv({ cls: "mandarin-view-header" });
    header.createEl("h4", { text: "Mandarin" });
    const reload = header.createEl("button", { text: "Refresh" });
    reload.addEventListener("click", () => this.refresh());
    const sections = [
      ["Overdue", "done = false && due_date < now/d"],
      ["Today", "done = false && due_date >= now/d && due_date < now/d+1d"],
      ["Next 7 days", "done = false && due_date >= now/d+1d && due_date < now/d+8d"]
    ];
    for (const [title, filter] of sections) {
      const section = root.createDiv({ cls: "mandarin-section" });
      section.createEl("h5", { text: title });
      try {
        renderTasks(section, await this.plugin.api.tasks(filter), this.plugin, () => this.refresh());
      } catch (e) {
        section.createDiv({ cls: "mandarin-muted", text: errorText(e) });
        break;
      }
    }
  }
};
var RecipeModal = class extends import_obsidian.FuzzySuggestModal {
  constructor(plugin) {
    super(plugin.app);
    this.plugin = plugin;
    this.setPlaceholder("Loading recipes\u2026");
    plugin.api.recipes().then((recipes) => {
      this.recipes = recipes;
      this.setPlaceholder("Pick a recipe to save as a note");
      this.inputEl.dispatchEvent(new Event("input"));
    }).catch((e) => {
      new import_obsidian.Notice(`Couldn't load recipes. ${errorText(e)}`);
      this.close();
    });
  }
  plugin;
  recipes = [];
  getItems() {
    return this.recipes;
  }
  getItemText(recipe) {
    return [recipe.title, ...recipe.tags].join(" \xB7 ");
  }
  onChooseItem(recipe) {
    this.plugin.saveRecipe(recipe);
  }
};
var MandarinSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  plugin;
  projects = [];
  display() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    containerEl.empty();
    const text = (name, desc, key, secret = false) => new import_obsidian.Setting(containerEl).setName(name).setDesc(desc).addText((input) => {
      input.setValue(String(s[key])).onChange(async (value) => {
        s[key] = value.trim();
        await this.plugin.saveSettings();
      });
      if (secret) input.inputEl.type = "password";
    });
    text("Mandarin address", "The address you open Mandarin at, e.g. https://mandarin.example.com", "url");
    text("API token", "Mandarin \u2192 Settings \u2192 API tokens. Give it: projects (read all), tasks (read all, create, update), recipes (read all, read one, images).", "token", true);
    new import_obsidian.Setting(containerEl).setHeading().setName("Cloudflare Zero Trust");
    text("Service token client ID", "Cloudflare Zero Trust \u2192 Access \u2192 Service credentials. Leave empty if Mandarin isn't behind Access.", "cfClientId");
    text("Service token client secret", "", "cfClientSecret", true);
    new import_obsidian.Setting(containerEl).setHeading().setName("Tasks and recipes");
    new import_obsidian.Setting(containerEl).setName("Project for new tasks").setDesc('Where "Create task from this line" puts tasks.').addDropdown((dropdown) => {
      dropdown.addOption("0", this.projects.length ? "Choose\u2026" : "Test the connection to load projects");
      for (const p of this.projects.filter((p2) => !p2.is_archived)) dropdown.addOption(String(p.id), p.title);
      dropdown.setValue(String(s.defaultProjectId)).onChange(async (value) => {
        s.defaultProjectId = Number(value);
        await this.plugin.saveSettings();
      });
    });
    text("Due time", "For due dates written without a time (\u{1F4C5} 2026-11-03), as HH:MM.", "defaultDueTime");
    text("Recipe folder", "Where saved recipes go; pictures go in its attachments folder.", "recipeFolder");
    new import_obsidian.Setting(containerEl).setHeading().setName("Finished tasks in the daily note");
    new import_obsidian.Setting(containerEl).setDesc(
      `"Add finished tasks to the daily note" lists the tasks finished that day in the projects ticked here (and their sub-projects). It uses the folder, date format and template from Obsidian's Daily notes settings.`
    );
    if (this.projects.length === 0) {
      new import_obsidian.Setting(containerEl).setName("Projects").setDesc("Test the connection (below) to pick projects.");
    }
    for (const p of this.projects.filter((p2) => !p2.is_archived)) {
      new import_obsidian.Setting(containerEl).setName(p.title).addToggle((toggle) => toggle.setValue(s.finishedProjectIds.includes(p.id)).onChange(async (on) => {
        s.finishedProjectIds = on ? [...s.finishedProjectIds, p.id] : s.finishedProjectIds.filter((id) => id !== p.id);
        await this.plugin.saveSettings();
      }));
    }
    text("Heading", "Put this heading in your daily-note template to choose where the list goes; otherwise it's added at the end.", "finishedHeading");
    new import_obsidian.Setting(containerEl).setName("Keep it up to date").setDesc("Update today's note when Obsidian starts and every 30 minutes (yesterday's too, at start-up). Turn it on for one device only.").addToggle((toggle) => toggle.setValue(s.finishedAuto).onChange(async (on) => {
      s.finishedAuto = on;
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("Test the connection").addButton((button) => button.setButtonText("Test").onClick(async () => {
      try {
        this.projects = await this.plugin.api.projects();
        new import_obsidian.Notice(`Connected: ${this.projects.length} projects.`);
        this.display();
      } catch (e) {
        new import_obsidian.Notice(`Mandarin: ${errorText(e)}`);
      }
    }));
  }
};
